#include "Repository.h"
#include "Service.h"
#include "UI.h"

#include <string>
#include <sstream>
#include <iostream>
#include <crtdbg.h>

int main()
{
	/*test_victim();
	test_file_repository();
	test_csv_repository();
	test_service();*/
	{
		FileRepository repository{};
		Repository* assistant_repository{};
		Service service{ repository,assistant_repository };
		UI ui{ service };

		ui.run();
			
	}

	_CrtDumpMemoryLeaks();
	return 0;
}