#include "UI.h"
#include <string>
#include <sstream>
#include <vector>
#include <iostream>


using namespace std;

void UI::list_all_ui()
{
	Dynamic_vector victims = this->service.get_all_victims_in_repository();
	for (int i = 0; i < victims.get_size(); i++)
	{
		Victim victim = victims.get_element(i);
		cout << victim.victim_to_string() << endl;
	}
}

void UI::run()
{
	int mode = -1;
	while (true)
	{	
		std::string command, command_key, argument_1, argument_2, argument_3, argument_4;
		getline(cin, command);
		std::stringstream command_stream(command);
		std::getline(command_stream, command_key, ' ');

		if (command_key == "exit")
		{
			break;
		}
		else if (command_key == "mode")
		{
			std::getline(command_stream, argument_1, ',');
			if (argument_1 == "A")
				mode = 1;
			if (argument_1 == "B")
				mode = 0;
		}
		else if (command_key == "delete")
		{
			std::getline(command_stream, argument_1, ',');

			if (mode == 1)
				this->service.remove_victim_service(argument_1);
			else cout << "wrong mode" << endl;
		}
		else if (command_key == "add")
		{
			
			std::getline(command_stream, argument_1, ',');
			std::getline(command_stream, argument_2, ',');
			if (argument_2.at(0) == ' ')
				argument_2 = argument_2.erase(0, 1);
			std::getline(command_stream, argument_3, ',');
			if (argument_3.at(0) == ' ')
				argument_3 = argument_3.erase(0, 1);
			std::getline(command_stream, argument_4, ',');
			if (argument_4.at(0) == ' ')
				argument_4 = argument_4.erase(0, 1);

			int age;
			stringstream age_string(argument_3);
			age_string >> age;

			if (mode == 1 && age != 0)
				this->service.add_victim_service(argument_1, argument_2, age, argument_4);
			else if (age == 0)
				cout << "No!" << endl;
			else cout << "wrong mode" << endl;
		}
		else if (command_key == "update")
		{
			std::getline(command_stream, argument_1, ',');
			std::getline(command_stream, argument_2, ',');
			if (argument_2.at(0) == ' ')
				argument_2 = argument_2.erase(0, 1);
			std::getline(command_stream, argument_3, ',');
			if (argument_3.at(0) == ' ')
				argument_3 = argument_3.erase(0, 1);
			std::getline(command_stream, argument_4, ',');
			if (argument_4.at(0) == ' ')
				argument_4 = argument_4.erase(0, 1);

			int age;
			stringstream age_string(argument_3);
			age_string >> age;


			if (mode == 1 && age!= 0)
				this->service.update_victim_service(argument_1, argument_2, age, argument_4);
			else if (age == 0)
				cout << "No!" << endl;
			else cout << "wrong mode" << endl;
		}
		else if (command_key == "list")
			this->list_all_ui();
		else
		{
			cout << "wrong command" << endl;
		}
	}	
	
}